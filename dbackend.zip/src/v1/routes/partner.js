const express = require('express');
var router = express.Router();
const Joi = require('@hapi/joi');
const partnerService = require('../services/partnerService');
const SUCCESSMSG = require("../lang/success");

router.get('/', async (req, res) => {
    const { error } = validateGetPartnerList(req.query);
    if (error) return req.app.responseHelper.send(res, false, {}, [{ "msg": error.details[0].message }], 500);

    const result = await partnerService.getPartnerList(req.query);
    let responseObj = result;
    responseObj['message'] = SUCCESSMSG[3001];

    return req.app.responseHelper.send(res, true, responseObj, [], 200);
});


function validateGetPartnerList(payload) {
    const schema = {
        userId: Joi.string().required(),
        startIndex: Joi.number(),
        limit: Joi.number(),
        searchKey: Joi.string(),
        allFields: Joi.boolean()
    }
    return Joi.validate(payload, schema);
}
module.exports = router;