module.exports = {
    1: 'Produce Asset',
    2: 'Consume Asset',   
    3: 'Receive Asset',  
    4: 'Revoked',
    5: 'Closed',
    6: 'Cancelled',
    7: 'Credit',     
}
